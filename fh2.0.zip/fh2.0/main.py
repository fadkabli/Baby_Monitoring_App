from threading import Thread
from flask import Flask, render_template, Response, request
import cv2
import numpy as np
import time
import json
from traking import PoseEstimation, CameraOps
from pushbullet import Pushbullet
import requests
import time
from pygame import mixer


################### INPUTS HERE ################################
camera_source ='baby_aboveNight2.avi'  # put "0" for webcam

################### INPUTS HERE ################################


camera = CameraOps(camSource=camera_source)

app = Flask(__name__)
message_sent = False


##########   GLOBAL variables ##########
detected_data = {"warning_message" : "", "warning_severity" : "LOW"}

#PUSH_BULLET_API_KEY = "xxxxxx" # PUSHBULLET API KEY WILL BE HERE

NOTIFICATION_DELAY = 30000 # in miliseconds (1 minutes delay = 60seconds * 1000 miliseconds)

warning_time = 0 # Recent warning time in miliseconds

#pb = Pushbullet(PUSH_BULLET_API_KEY)

################################################### DETECTION [START]########################################################
@app.route("/getResult")
def getResult():
    """Function called from javascript after every 0.5 seconds 
    in id_assigning.html for displaying person recognized and QR code"""

    global warning_time

    global NOTIFICATION_DELAY

    current_time = int(round(time.time() * 1000))

    mixer.init() #calling mixer for sound
    if detected_data['warning_severity'] == 'HIGH':

        #adding sound file to mixer
        mixer.music.load('sound.wav')
        mixer.music.play() #playing sound
        time.sleep(0.5)
        # Baby in danger, send notification if it's first warning or warning after 1 minute delay

        warning_time_with_delay = warning_time + NOTIFICATION_DELAY

        if warning_time == 0 or current_time > warning_time_with_delay:
            warning_time = current_time  # Update warning time
            send_notification(detected_data['warning_message'])


    elif detected_data['warning_severity'] == 'LOW' or detected_data['warning_severity'] == 'MEDIUM':

        mixer.music.stop()  #stopping the sound


    object_json = json.dumps(detected_data)
   
    return object_json

def get_detection_result():
    """This function yeilds frames for streaming on detection/ recognition page. Also it stores realtime
    face detected person name and QR code values in dictionary called detected_data"""
    global detected_data
    timest = time.time()
    
    t1 = Thread(target = camera.start_cam_stream)   
    t1.start()
    if camera.toStream==True:
        while True:
            if camera.curFrame is not None:
                ret, buffer = cv2.imencode('.jpg', camera.curFrame)
                detected_data["warning_message"] = camera.warning_message
                detected_data["warning_severity"] = camera.warning_severity

                frame = buffer.tobytes()
                yield (b'--frame\r\n'
                        b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')  # concat frame one by one and show result
            else:
                time.sleep(0.5)
            if camera.toStream==False:
                break





@app.route("/vid_stream")
def vid_stream():
    """ Function called from id_assigning.html to render steam to show on web page """   
    return Response(get_detection_result(), mimetype='multipart/x-mixed-replace; boundary=frame')


################################################### DETECTION [END] ########################################################
@app.route("/stop_all_cameras", methods=['POST'])
def stop_all_cameras():
    global camera
    if camera is not None:
        camera.toStream = False

    return render_template('index.html')

@app.route('/start_stream', methods=['post'])
def start_stream():
    global camera
    if camera is not None:
        camera.toStream = True

    return render_template('index.html')


@app.route('/', methods=['GET','POST'])
def index():
    global camera
    stop_all_cameras()
    camera.toStream = True

    return render_template('index.html')

#send notification to user device
def send_notification(warning_message):
    title = "BABY MONITORING"
    body = warning_message
   # pb.push_note(title, body)
    return 'Notification Sent'


if __name__ == "__main__":

   app.run(debug=True, host="0.0.0.0", port=5000, use_reloader=False)
    #app.run(debug=True, host="172.20.10.8", port=5000, use_reloader=False)
